#!/bin/bash

### Init configuration iptables & tc
