 Directory layout
--------------------

  stats/		- Contains scripts to gather statistics data from OpenJSIP services.

