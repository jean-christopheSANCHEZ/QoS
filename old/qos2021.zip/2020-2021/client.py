import socket
#import ipaddress

hote = "192.168.1.20"
port = 9000

socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)





socket.connect((hote, port))
print("Connection on {}".format(port))

msg = """
v=0
o=user1 0 0 IN IP4 192.168.2.1
s=-
c=IN IP4 192.168.2.1
t=0 0
m=audio 5085 RTP/AVP 9 96 97 98 100 0 8 102 3 103 5 6 101
a=rtpmap:9 G722/8000
a=rtpmap:96 SILK/24000
a=rtpmap:97 SILK/16000
a=rtpmap:98 speex/32000
a=rtpmap:100 speex/16000
a=rtpmap:0 PCMU/8000
a=rtpmap:8 PCMA/8000
a=rtpmap:102 iLBC/8000
a=rtpmap:3 GSM/8000
a=rtpmap:103 speex/8000
a=rtpmap:5 DVI4/8000
a=rtpmap:6 DVI4/16000
a=rtpmap:101 telephone-event/8000
a=extmap:1 urn:ietf:params:rtp-hdrext:csrc-audio-level
a=zrtp-hash:1.10 36defd88cb8248f06acb912d7b56091aadf405ce10aeb6807c0dfc045039d6d0
m=video 5087 RTP/AVP 104 99
a=recvonly
a=rtpmap:104 H264/90000
a=fmtp:104 profile-level-id=4DE01f;packetization-mode=1
a=imageattr:104 send * recv [x=[0-1920],y=[0-1080]]
a=rtpmap:99 H264/90000
a=fmtp:99 profile-level-id=4DE01f
a=imageattr:99 send * recv [x=[0-1920],y=[0-1080]]
a=zrtp-hash:1.10 c5357d7a1ee46edf5b292e401013665807152e1bf2d9906d601f5752683f6007
###v=0
o=user2 0 0 IN IP4 192.168.1.1
s=-
c=IN IP4 192.168.1.1
t=0 0
m=audio 5077 RTP/AVP 9 96 97 98 100 0 8 102 3 103 5 6 101
a=rtpmap:9 G722/8000
a=rtpmap:96 SILK/24000
a=rtpmap:97 SILK/16000
a=rtpmap:98 speex/32000
a=rtpmap:100 speex/16000
a=rtpmap:0 PCMU/8000
a=rtpmap:8 PCMA/8000
a=rtpmap:102 iLBC/8000
a=rtpmap:3 GSM/8000
a=rtpmap:103 speex/8000
a=rtpmap:5 DVI4/8000
a=rtpmap:6 DVI4/16000
a=rtpmap:101 telephone-event/8000
a=extmap:1 urn:ietf:params:rtp-hdrext:csrc-audio-level
m=video 5079 RTP/AVP 104 99
a=inactive
a
"""
bytes_msg = bytes(msg,'utf-8')
socket.send(bytes_msg)

print("Close")
socket.close()
